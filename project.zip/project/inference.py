import os
import argparse
import torch
import numpy as np
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader

# Import the previously defined modules
from project.model import GraphSRFlowModel
from project.dataset import CalorimeterSRDataset

def solve_ode_euler(model, lr_features, num_steps=50, device="cpu"):
    """
    Integrates the predicted vector field from t=0 to t=1 using the Euler method.
    """
    B, N, C = lr_features.shape
    
    # 1. Start with random noise at t=0
    x_t = torch.randn((B, N, C), device=device)
    
    # Time step size
    dt = 1.0 / num_steps
    
    # 2. Iteratively update x_t
    for step in range(num_steps):
        # Create a time tensor for the current step
        t_val = step / num_steps
        t_tensor = torch.full((B,), t_val, device=device)
        
        # Predict the vector field direction
        with torch.no_grad():
            v_pred = model(x_t, lr_features, t_tensor)
        
        # Euler step: x_{t+dt} = x_t + v * dt
        x_t = x_t + v_pred * dt
        
    # The final x_t at t=1 is our predicted high-resolution sample
    return x_t

def plot_calorimeter_event(lr, hr, pred, save_path):
    """
    Visualizes the calorimeter event in the eta-phi plane.
    Marker size/color represents energy.
    Assumes features are: [Energy, Eta, Phi]
    """
    fig, axes = plt.subplots(1, 3, figsize=(18, 5), sharex=True, sharey=True)
    titles = ["Low Resolution (Input)", "High Resolution (Target)", "Predicted (Ensemble Mean)"]
    data = [lr, hr, pred]
    
    for ax, event, title in zip(axes, data, titles):
        # Extract features (un-batching assuming B=1)
        energy = event[:, 0]
        eta = event[:, 1]
        phi = event[:, 2]
        
        # Plot: x=eta, y=phi, color & size=energy
        # We use a positive offset for marker size so 0 energy still shows a dot
        scatter = ax.scatter(eta, phi, c=energy, s=(energy - energy.min() + 0.1)*50, 
                             cmap='viridis', alpha=0.7)
        ax.set_title(title)
        ax.set_xlabel("Pseudorapidity (Eta)")
        ax.set_ylabel("Azimuthal Angle (Phi)")
        plt.colorbar(scatter, ax=ax, label="Normalized Energy")
        
    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    print(f"Visualization saved to {save_path}")
    plt.close()

def main():
    parser = argparse.ArgumentParser(description="Inference for Calorimeter Super-Resolution")
    parser.add_argument("--ckpt_path", type=str, required=True, help="Path to trained PyTorch Lightning checkpoint")
    parser.add_argument("--data_file", type=str, required=True, help="Path to a test .root file")
    parser.add_argument("--num_ensemble", type=int, default=10, help="Number of forward passes to average")
    parser.add_argument("--ode_steps", type=int, default=50, help="Number of integration steps for the ODE solver")
    parser.add_argument("--output_dir", type=str, default="./outputs", help="Where to save predictions and plots")
    parser.add_argument("--sample_idx", type=int, default=0, help="Which event index from the dataset to visualize")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # 1. Load Model
    print(f"Loading model from {args.ckpt_path}...")
    model = GraphSRFlowModel.load_from_checkpoint(args.ckpt_path)
    model.to(device)
    model.eval()

    # 2. Load Dataset Sample
    print(f"Loading data from {args.data_file}...")
    dataset = CalorimeterSRDataset(args.data_file, as_graph=False, normalize=True)
    
    # Extract the specific sample
    lr_tensor, hr_tensor = dataset[args.sample_idx]
    
    # Add batch dimension and move to device
    lr_batch = lr_tensor.unsqueeze(0).to(device)
    hr_batch = hr_tensor.unsqueeze(0).to(device)

    # 3. Perform Ensemble Inference
    print(f"Running ODE solver {args.num_ensemble} times to build ensemble...")
    predictions = []
    
    for i in range(args.num_ensemble):
        print(f"  Sampling generation {i+1}/{args.num_ensemble}...")
        pred = solve_ode_euler(model, lr_batch, num_steps=args.ode_steps, device=device)
        predictions.append(pred)
        
    # Stack all predictions and take the mean across the ensemble dimension
    # Shape of stacked: [Ensemble, Batch, Nodes, Features]
    stacked_preds = torch.stack(predictions)
    mean_pred = stacked_preds.mean(dim=0)

    # 4. Save Raw Tensors
    output_tensor_path = os.path.join(args.output_dir, f"prediction_event_{args.sample_idx}.pt")
    torch.save({
        "lr_input": lr_batch.cpu(),
        "hr_target": hr_batch.cpu(),
        "pred_mean": mean_pred.cpu(),
        "pred_ensemble": stacked_preds.cpu()
    }, output_tensor_path)
    print(f"Tensors saved to {output_tensor_path}")

    # 5. Visualize Results
    # Squeeze batch dimension and convert to numpy for plotting
    plot_calorimeter_event(
        lr=lr_batch.squeeze(0).cpu().numpy(),
        hr=hr_batch.squeeze(0).cpu().numpy(),
        pred=mean_pred.squeeze(0).cpu().numpy(),
        save_path=os.path.join(args.output_dir, f"event_{args.sample_idx}_viz.png")
    )

if __name__ == "__main__":
    main()